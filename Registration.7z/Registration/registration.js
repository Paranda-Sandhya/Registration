function chkEmpty(){
	

	if (document.frm1.userName.value == "") {alert("Please fill the First Name");}
	if (document.frm1.city.value == "") {alert("Please fill the city");}
	if (document.frm1.password.value == "") {alert("Please fill the password");}
	else {
		alert(" completed Successfully.");
			}
		}