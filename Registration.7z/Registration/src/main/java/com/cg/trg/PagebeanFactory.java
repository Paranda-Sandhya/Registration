package com.cg.trg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PagebeanFactory {
	

private WebDriver driver;
	public PagebeanFactory()
	{
	
	}
	
	public PagebeanFactory(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
		}
	@FindBy(xpath="/html/body/form/input[2]")
	@CacheLookup
	WebElement userName;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement password;
	

	@FindBy(xpath="/html/body/form/input[6]")
	@CacheLookup
	WebElement button1;
	

	@FindBy(xpath="/html/body/form/input[7]")
	@CacheLookup
	WebElement checkbox1;
	
	

	@FindBy(xpath="/html/body/form/input[8]")
	@CacheLookup
	WebElement checkbox2;
	
	@FindBy(xpath="/html/body/form/input[15]")
	@CacheLookup
	WebElement store;
	
	public WebElement getStore() {
		return store;
	}

	public void setStore( ) {
		this.store.click();
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	
	public void setButton1( ) {
		this.button1.click();
	}

	public WebElement getCheckbox1() {
		return checkbox1;
	}

	public void setCheckbox1(WebElement checkbox1) {
		this.checkbox1 = checkbox1;
	}

	public WebElement getCheckbox2() {
		return checkbox2;
	}

	public void setCheckbox2(WebElement checkbox2) {
		this.checkbox2 = checkbox2;
	}

	
	
	

}
