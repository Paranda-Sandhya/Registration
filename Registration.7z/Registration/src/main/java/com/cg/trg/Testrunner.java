package com.cg.trg;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"usage","json:jsonop/json-output"},features= {"src/test/java"},glue= {"com.cg.trg"})
public class Testrunner {

}
