package com.cg.trg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registrationstepdef {
	private PagebeanFactory factory;
	private WebDriver driver;

	

@Given("^User enters username$")
public void user_enters_username() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\Softwares\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	factory = new PagebeanFactory(driver);
	driver.get("file:\\D:\\SpringProjects\\Registration\\registration.html");
   
}

@When("^username is empty$")
public void username_is_empty() throws Throwable {
	factory.setUserName("");
	factory.setStore();


}



@Given("^User enters city$")
public void user_enters_city() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\Softwares\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	factory = new PagebeanFactory(driver);
	driver.get("file:\\D:\\SpringProjects\\Registration\\registration.html");
}

@When("^city is empty$")
public void city_is_empty() throws Throwable {
	factory.setUserName("Swaty");
	factory.setCity("");
	factory.setStore();

   
}

@Given("^User enters password$")
public void user_enters_password() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\Softwares\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	factory = new PagebeanFactory(driver);
	driver.get("file:\\D:\\SpringProjects\\Registration\\registration.html");}

@When("^password is empty$")
public void password_is_empty() throws Throwable {
	factory.setUserName("Sandy");
	factory.setCity("Hyderabad");
	factory.setPassword("");
	factory.setStore();

}

@Given("^User enters gender$")
public void user_enters_gender() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\Softwares\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	factory = new PagebeanFactory(driver);
	driver.get("file:\\D:\\SpringProjects\\Registration\\registration.html");}

@When("^Gender is empty$")
public void gender_is_empty() throws Throwable {
	//factory.setButton1(null);
	factory.setUserName("");
	factory.setCity("");
	factory.setPassword("");
	factory.setStore();
}

@Given("^User enters Languagesknown$")
public void user_enters_Languagesknown() throws Throwable {
  
}

@When("^Languagesknown is empty$")
public void languagesknown_is_empty() throws Throwable {
   
}
@Then("^Print error message$")
public void print_error_message() throws Throwable {
	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	System.out.println("alert Enter valid details :: "+alertMessage);
	Thread.sleep(2000);
	driver.close();
}


	
}
